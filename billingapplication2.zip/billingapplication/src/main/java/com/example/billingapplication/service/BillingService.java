package com.example.billingapplication.service;

import com.example.billingapplication.model.Billing;
import com.example.billingapplication.model.Customer;
import com.example.billingapplication.model.Product;
import com.example.billingapplication.repository.BillingRepository;
import com.example.billingapplication.repository.CustomerRepository;
import com.example.billingapplication.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillingService {
    @Autowired
    private BillingRepository billingRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CustomerRepository customerRepository;

    public Billing createBilling(Long customerId, List<Long> productIds){
        Customer Customer = customerRepository.findById(customerId).orElseThrow();
        List<Product> products =productRepository.findAllById(productIds);

        double totalAmount = products.stream().mapToDouble(Product::getPrice).sum();

        Billing billing = new Billing();
        billing.setCustomer(Customer);
        billing.setProducts(products);
        billing.setTotalAmount(totalAmount);
        return billingRepository.save(billing);
    }

}
