package com.example.billingapplication.exception;

public class CustomerNotFoundException extends RuntimeException{
    public CustomerNotFoundException(long customerId){
        super("Customer with Id : " +customerId + " not found!!");
    }
}
