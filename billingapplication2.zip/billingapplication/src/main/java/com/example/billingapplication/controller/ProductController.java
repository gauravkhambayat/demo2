package com.example.billingapplication.controller;

import com.example.billingapplication.model.Product;
import com.example.billingapplication.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/billingapp/product")
public class ProductController {
    @Autowired
    private ProductService productService;

    @PostMapping("/save")
    public ResponseEntity<Product> saveNewProduct(@RequestBody Product product){
        return ResponseEntity.ok().body(productService.saveProduct(product));
    }
    @GetMapping("/all")
    public ResponseEntity<List<Product>> viewAllProducts(){
        return ResponseEntity.ok(productService.getAllProducts());
    }
    @PutMapping("/update/{productId}")
    public ResponseEntity<Product> updateProduct(@PathVariable long productId, @RequestBody Product product){
        Product p = productService.updateProduct(product,productId);
        return ResponseEntity.ok(p);
    }

    @DeleteMapping("/delete/{productId}")
    public ResponseEntity<String> deleteProduct(@PathVariable long productId){
        productService.deleteProduct(productId);
        return ResponseEntity.ok("Deleted Product with Id : " +productId);
    }

}
