package com.example.billingapplication.controller;

import com.example.billingapplication.exception.CustomerNotFoundException;
import com.example.billingapplication.model.Customer;
import com.example.billingapplication.model.Product;
import com.example.billingapplication.service.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/billingapp/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/save")
    public ResponseEntity<Customer> saveNewProduct(@RequestBody Customer customer){
        return ResponseEntity.ok().body(customerService.saveCustomer(customer));
    }
    @GetMapping("/all")
    public ResponseEntity<List<Customer>> viewAllCustomers(){
        return ResponseEntity.ok(customerService.getAllCustomers());
    }
    @PutMapping("/update/{customerId}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable long customerId, @RequestBody Customer customer) throws CustomerNotFoundException {
        Customer c = customerService.updateCustomer(customer,customerId);
        return ResponseEntity.ok(c);
    }
    @DeleteMapping("/delete/{customerId}")
    public ResponseEntity<String> deleteCustomer(@PathVariable long customerId){
        customerService.deleteCustomer(customerId);
        return ResponseEntity.ok("Deleted Customer with Id : " +customerId);
    }

}
