package com.example.billingapplication.exception;

public class ProductNotFoundException extends RuntimeException{
    public ProductNotFoundException(long productId){
        super("Product with Id : " +productId + " not found!!");
    }
}
