package com.example.billingapplication.service;

import com.example.billingapplication.exception.CustomerNotFoundException;
import com.example.billingapplication.exception.ProductNotFoundException;
import com.example.billingapplication.model.Customer;
import com.example.billingapplication.model.Product;
import com.example.billingapplication.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public Product saveProduct(Product product){
        return productRepository.save(product);
    }

    public List<Product> getAllProducts(){
        return productRepository.findAll();
    }

    public Product updateProduct(Product product,long productId){
     Optional existingProduct = productRepository.findById(productId);
        if(existingProduct.isPresent()){
            Product product1 = (Product) existingProduct.get();
            product1.setBrand(product.getBrand());
            product1.setCategory(product.getCategory());
            product1.setName(product.getName());
            product1.setQuantity(product.getQuantity());
            product1.setPrice(product.getPrice());
            product1.setSupplier(product.getSupplier());
            return productRepository.save(product1);
        }
        else{
            throw new ProductNotFoundException(productId);
        }
    }

    public void deleteProduct(long productId){
        Optional existingProduct = productRepository.findById(productId);
        if(existingProduct.isPresent()){
            productRepository.deleteById(productId);}
        else{
            throw new ProductNotFoundException(productId);
        }
    }
}
