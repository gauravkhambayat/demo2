package com.example.billingapplication.model;

import jakarta.persistence.*;

import java.util.List;
import java.util.Set;

@Entity
public class Billing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "customers_id")
    private Customer customer;

    @ManyToMany
    @JoinTable(name ="billing_products", joinColumns = @JoinColumn(name="billing_id"),inverseJoinColumns = @JoinColumn(name = "products_id"))
    private List<Product> products;

    private double totalAmount;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Billing(long id, Customer customer, List<Product> products, double totalAmount) {
        this.id = id;
        this.customer = customer;
        this.products = products;
        this.totalAmount = totalAmount;
    }

    public Billing() {
    }
}
