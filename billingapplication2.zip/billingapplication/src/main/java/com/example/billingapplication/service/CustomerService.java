package com.example.billingapplication.service;

import com.example.billingapplication.exception.CustomerNotFoundException;
import com.example.billingapplication.model.Customer;
import com.example.billingapplication.model.Product;
import com.example.billingapplication.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    public Customer saveCustomer(Customer customer){
        return customerRepository.save(customer);
    }

    public List<Customer> getAllCustomers(){
        return customerRepository.findAll();
    }

    public Customer updateCustomer(Customer customer, long customerId){

        Optional existingCustomer = customerRepository.findById(customerId);
        if(existingCustomer.isPresent()){
            Customer customer1 = (Customer) existingCustomer.get();
            customer1.setContact(customer.getContact());
            customer1.setEmail(customer.getEmail());
            customer1.setGender(customer.getGender());
            customer1.setName(customer.getName());
            return customerRepository.save(customer1);
        }
        else{
            throw new CustomerNotFoundException(customerId);
        }

    }

    public void deleteCustomer(long customerId){

        Optional existingCustomer = customerRepository.findById(customerId);
        if(existingCustomer.isPresent()){
        customerRepository.deleteById(customerId);}
        else{
            throw new CustomerNotFoundException(customerId);
        }
    }
}
