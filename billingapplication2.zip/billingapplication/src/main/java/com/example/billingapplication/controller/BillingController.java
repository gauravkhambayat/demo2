package com.example.billingapplication.controller;

import com.example.billingapplication.model.Billing;
import com.example.billingapplication.service.BillingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/billingapp/billings")
public class BillingController {
    @Autowired
    private BillingService billingService;

    @PostMapping
    public ResponseEntity<Billing> createBilling(@RequestParam Long customerId, @RequestParam List<Long> productIds){
        Billing billing = billingService.createBilling(customerId,productIds);
        return ResponseEntity.ok(billing);
    }
}
