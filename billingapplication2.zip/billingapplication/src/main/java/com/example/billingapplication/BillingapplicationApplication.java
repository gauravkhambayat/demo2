package com.example.billingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingapplicationApplication.class, args);
	}

}
