package com.example.billingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
